#include "Vector2.h"

struct Vector2
{
    int x, y;

    // ������
    Vector2(int _x = 0, int _y = 0) : x(_x), y(_y) {}

    // ����
    Vector2 operator+(const Vector2& rhs) const
    {
        return Vector2(x + rhs.x, y + rhs.y);
    }

    // ����
    Vector2 operator-(const Vector2& rhs) const
    {
        return Vector2(x - rhs.x, y - rhs.y);
    }

    // ���� (��Į��)
    Vector2 operator*(int scalar) const
    {
        return Vector2(x * scalar, y * scalar);
    }

    // ������ (��Į��)
    Vector2 operator/(int scalar) const
    {
        return Vector2(x / scalar, y / scalar);
    }

    // ��
    bool operator==(const Vector2& rhs) const
    {
        return x == rhs.x && y == rhs.y;
    }

    bool operator!=(const Vector2& rhs) const
    {
        return !(*this == rhs);
    }
};