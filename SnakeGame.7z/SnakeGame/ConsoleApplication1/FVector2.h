#pragma once

struct FVector2
{
    int x, y;

    // ������
    FVector2(int _x = 0, int _y = 0) : x(_x), y(_y) {}

    // ����
    FVector2 operator+(const FVector2& rhs) const
    {
        return FVector2(x + rhs.x, y + rhs.y);
    }

    // ����
    FVector2 operator-(const FVector2& rhs) const
    {
        return FVector2(x - rhs.x, y - rhs.y);
    }

    // ���� (��Į��)
    FVector2 operator*(int scalar) const
    {
        return FVector2(x * scalar, y * scalar);
    }

    // ������ (��Į��)
    FVector2 operator/(int scalar) const
    {
        return FVector2(x / scalar, y / scalar);
    }

    // Vector2 �߰�
    FVector2& operator+=(const FVector2& inputVector)
    {
        x += inputVector.x;
        y += inputVector.y;
        return *this;
    }

    // Vector2 ����
    FVector2& operator-=(const FVector2& inputVector)
    {
        x -= inputVector.x;
        y -= inputVector.y;
        return *this;
    }

    // ��
    bool operator==(const FVector2& rhs) const
    {
        return x == rhs.x && y == rhs.y;
    }

    bool operator!=(const FVector2& rhs) const
    {
        return !(*this == rhs);
    }
};