﻿#include "iostream"
#include "conio.h"
#include "windows.h"
#include "cstdlib"  // rand()
#include "ctime"    // srand()
#include "FVector2.h"

static const FVector2 DisplayRes = FVector2(20, 20);
static const FVector2 StartPoint = FVector2(10, 10);
static const int MaxtailSize = 100;

FVector2 SnakeHeadPoint = StartPoint;
int CurrentSnakeLength = 0;
FVector2 Direction = FVector2(1, 0);

struct FBodySegment
{
    bool bIsActive = false;
    FVector2 Position;
};

FBodySegment* TailPoints = new FBodySegment[MaxtailSize]; // 몸통 구현
FVector2 FoodPoint;

HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

//먹이 생성. 단. 뱀과 겹치지 않도록
void SpawnFood()
{
    while (true) //뱀과 겹치지 않을 때까지 계속 음식 위치 생성 하면서 검사
    {
        int x = rand() % DisplayRes.x;
        int y = rand() % DisplayRes.y;
        bool bCollides = (SnakeHeadPoint.x == x && SnakeHeadPoint.y == y);

        for (int i = 0; i < CurrentSnakeLength; i++)
        {
            if (TailPoints[i].bIsActive && TailPoints[i].Position.x == x && TailPoints[i].Position.y == y)
                bCollides = true;
        }

        if (!bCollides)
        {
            FoodPoint = FVector2(x, y);
            break;
        }
    }
}

void Draw()
{
    system("cls");
    std::cout << "뱀 머리: (" << SnakeHeadPoint.x << ", " << SnakeHeadPoint.y << ")  길이: " << CurrentSnakeLength << "\n\n";

    // 뱀 이동
    FVector2 NextTarget = SnakeHeadPoint + Direction;
    bool bIsCollideWall = (NextTarget.x < 0 || NextTarget.x >= DisplayRes.x ||
        NextTarget.y < 0 || NextTarget.y >= DisplayRes.y);

    if (!bIsCollideWall)
    {
        // 꼬리 이동: 뒤에서 앞으로
        for (int i = CurrentSnakeLength - 1; i > 0; i--)
        {
            TailPoints[i].Position = TailPoints[i - 1].Position;
        }
        if (CurrentSnakeLength > 0)
            TailPoints[0].Position = SnakeHeadPoint;

        SnakeHeadPoint = NextTarget;
    }

    // 화면 그리기
    for (int i = 0; i < DisplayRes.y; i++)
    {
        for (int j = 0; j < DisplayRes.x; j++)
        {
            if (i == SnakeHeadPoint.y && j == SnakeHeadPoint.x) //머리 위치?
            {
                SetConsoleTextAttribute(hConsole, 10); // 초록
                std::cout << "● ";
            }
            else if (i == FoodPoint.y && j == FoodPoint.x)
            {
                SetConsoleTextAttribute(hConsole, 7); // 노랑/주황
                std::cout << "★ ";
            }
            else
            {
                bool bPrinted = false;
                for (int k = 0; k < CurrentSnakeLength; k++) 
                {
                    //몸통 출력
                    if (TailPoints[k].bIsActive && TailPoints[k].Position.x == j && TailPoints[k].Position.y == i)
                    {
                        SetConsoleTextAttribute(hConsole, 10); // 주황
                        std::cout << "■ ";
                        bPrinted = true;
                        break;
                    }
                }
                if (!bPrinted) //배경
                {
                    SetConsoleTextAttribute(hConsole, 8); // 기본
                    std::cout << "□ ";
                }
            }
        }
        std::cout << "\n";
    }

    SetConsoleTextAttribute(hConsole, 7); //화면색 기본값으로 복구
}

int main()
{
    srand((unsigned int)time(nullptr));
    for (int i = 0; i < MaxtailSize; i++)
        TailPoints[i].bIsActive = false;

    SpawnFood();

    while (true)
    {
        // 키 입력
        if (_kbhit())
        {
            int key = _getch();
            if (key == 'w' || key == 'W') Direction = FVector2(0, -1);
            if (key == 'a' || key == 'A') Direction = FVector2(-1, 0);
            if (key == 's' || key == 'S') Direction = FVector2(0, 1);
            if (key == 'd' || key == 'D') Direction = FVector2(1, 0);
            if (key == 27) break;
        }

        // 먹이 먹었는지 체크
        if (SnakeHeadPoint == FoodPoint)
        {
            if (CurrentSnakeLength < MaxtailSize)
            {
                TailPoints[CurrentSnakeLength].bIsActive = true;
                TailPoints[CurrentSnakeLength].Position = SnakeHeadPoint;
                CurrentSnakeLength++;
            }
            SpawnFood();
        }

        Draw();
        Sleep(500); // 0.5초마다 갱신
    }

    delete[] TailPoints;
    return 0;
}
